
<?php $__env->startSection('page_title','Business Information'); ?>
<?php $__env->startSection('businessactive_class','active'); ?>
<?php $__env->startSection('container'); ?>

<div class="col-12">
    <div class="form-business-box">
        <form action="<?php echo e(route('updatebusinessform', $customer->id )); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">

                <div class="col-12">
                    <div class="form-group mb-4">
                        <label for="exampleFormControlSelect2">Summary</label>
                        <textarea name="summary" class="form-control" rows="6" id="">
                            <?php echo e($business->summary ?? ''); ?>

                        </textarea>
                    </div>
                </div>

                <div class="col-xl-4 col-md-6 col-12">
                    <div class="form-group mb-4">
                        <div class="d-flex justify-content-between">
                            <label for="exampleFormControlSelect2">Province</label>
                            <small>
                                <a href="#" id="change-province" class="text-danger"
                                    style="<?php echo e(isset($business->state) ? '' : 'display:none;'); ?>">Change</a>
                            </small>
                        </div>

                        <?php if(isset($business->state)): ?>

                        <div class="address-box" id="province-input">
                            <?php echo e($business->stateshow->province_name ?? ''); ?>

                        </div>
                        <input type="hidden" name="state" id=""
                            value="<?php echo e($business->state); ?>">
                        <select name="state" id="province" class="form-control login-signup"
                            style="display: none;">
                            <option value="">- - Select Province - -</option>
                            <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data->id); ?>" <?php echo e($data->id == $business->state ? 'selected' : ''); ?>>
                                <?php echo e($data->province_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php else: ?>

                        <select name="state" id="province" class="form-control login-signup">
                            <option value="">- - Select Province - -</option>
                            <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data->id); ?>"><?php echo e($data->province_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-xl-4 col-md-6 col-12">
                    <div class="form-group mb-4">
                        <div class="d-flex justify-content-between">
                            <label for="exampleFormControlSelect2">District</label>
                            <small>
                                <a href="#" id="change-district" class="text-danger"
                                    style="<?php echo e(isset($business->district) ? '' : 'display:none;'); ?>">Change</a>
                            </small>
                        </div>

                        <?php if(isset($business->district)): ?>

                        <div class="address-box" id="district-input">
                            <?php echo e($business->districtshow->district_name ?? ''); ?>

                        </div>
                        <input type="hidden" name="district" id=""
                            value="<?php echo e($business->district); ?>">
                        <select id="district" name="district" class="form-control login-signup"
                            style="display: none;">

                        </select>

                        <?php else: ?>

                        <select id="district" name="district" class="form-control login-signup">

                        </select>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-xl-4 col-md-6 col-12">
                    <div class="form-group mb-4">
                        <div class="d-flex justify-content-between">
                            <label for="exampleFormControlSelect2">Municipality / Palika</label>
                            <small>
                                <a href="#" id="change-municipality" class="text-danger"
                                    style="<?php echo e(isset($business->municipality) ? '' : 'display:none;'); ?>">Change</a>
                            </small>
                        </div>

                        <?php if(isset($business->municipality)): ?>

                        <div class="address-box" id="municipality-input">
                            <?php echo e($business->municipalityshow->municipality_name ?? ''); ?>

                        </div>
                        <input type="hidden" name="municipality" id="hidden-temporary-muni"
                            value="<?php echo e($business->municipality); ?>">
                        <select id="municipality" name="municipality" class="form-control login-signup"
                            style="display: none;">

                        </select>

                        <?php else: ?>

                        <select id="municipality" name="municipality" class="form-control login-signup">

                        </select>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-xl-2 col-md-4 col-12">
                    <div class="form-group mb-4">
                        <label for="exampleFormControlSelect2">Ward</label>
                        <input type="number" class="form-control" name="ward" id="exampleFormControlInput1" value="<?php echo e($business->ward ?? ''); ?>">
                    </div>
                </div>
                
                <div class="col-xl-4 col-md-6 col-12">
                    <div class="form-group mb-4">
                        <label for="exampleFormControlSelect2">Tole</label>
                        <input type="text" class="form-control" name="tole" id="exampleFormControlInput1" value="<?php echo e($business->tole ?? ''); ?>">
                    </div>
                </div>
                
                <div class="col-xl-6 col-md-6 col-12">
                    <div class="form-group">
                        <label for="exampleFormControlSelect2">Address</label>
                        <input type="text" class="form-control" name="address" id="exampleFormControlInput1" value="<?php echo e($business->address ?? ''); ?>">
                    </div>
                </div>
                
                <div class="col-md-6 col-12">
                    <div class="form-group mb-4">
                        <label for="exampleFormControlSelect2">Latitude</label>
                        <input type="text" class="form-control" name="latitude" id="exampleFormControlInput1" value="<?php echo e($business->latitude ?? ''); ?>">
                    </div>
                </div>
                
                <div class="col-md-6 col-12">
                    <div class="form-group">
                        <label for="exampleFormControlSelect2">Longitude</label>
                        <input type="text" class="form-control" name="longitude" id="exampleFormControlInput1" value="<?php echo e($business->longitude ?? ''); ?>">
                    </div>
                </div>
                
                <div class="col-12">
                    <?php echo $__env->make('admin.auth.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                
                <div class="col-xl-4 col-md-6 col-12">
                    <div class="form-group mb-4">
                        <input type="submit" class="btn btn-warning text-white" value="Save">
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer/form-user/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\khojsansar\resources\views/customer/form-user/business.blade.php ENDPATH**/ ?>