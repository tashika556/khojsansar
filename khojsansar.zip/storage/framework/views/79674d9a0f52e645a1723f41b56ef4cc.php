
<?php $__env->startSection('page_title','Facility Information'); ?>
<?php $__env->startSection('facilityactive_class','active'); ?>
<?php $__env->startSection('container'); ?>

<div class="col-12">
    <div class="form-business-box">
    <form action="<?php echo e(route('updatebusinessfacilityform', $business->customer )); ?>" method="POST">
    <?php echo csrf_field(); ?>
            <div class="row">

                <div class="col-12">
                    <div class="form-group mb-4">
                        <label for="exampleFormControlSelect2"><strong>Could you please indicate which facilities your business offers ?</strong></label>
                        <div class="form-check">
                            <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="custom-checkbox-wrapper">
                                    <input type="checkbox" class="form-check-input" id="facility<?php echo e($facility->id); ?>" name="facilities[]" value="<?php echo e($facility->id); ?>"
                                    <?php echo e($business->facilities->contains($facility->id) ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="facility<?php echo e($facility->id); ?>">
                                        <?php echo e($facility->facility_name); ?>

                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

              
                
                <div class="col-12">
                    <?php echo $__env->make('admin.auth.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                
                <div class="col-xl-4 col-md-6 col-12">
                    <div class="form-group mb-4">
                        <input type="submit" class="btn btn-warning text-white" value="Save">
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer/form-user/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\khojsansar\resources\views/customer/form-user/facility.blade.php ENDPATH**/ ?>