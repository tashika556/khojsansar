<?php echo $__env->yieldPushContent('before-scripts'); ?>  

        <script src="<?php echo e(URL::asset('admin/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>


        <script src="<?php echo e(URL::asset('admin/js/show-password.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('frontend/js/font-awesom.js')); ?> "></script>
        <?php echo $__env->yieldPushContent('after-scripts'); ?>
   

	</body>

</html>
<?php /**PATH D:\khojsansar\resources\views/admin/footer.blade.php ENDPATH**/ ?>