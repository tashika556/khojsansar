<section class="testimonial">
    <div class="container">

        <div class="row">
            <div class="col-lg-6">
                <div class="testimonial_img">
                    <img src="img/testimonial-client.png" class="img-fluid w-100" alt="">
                </div>

            </div>
            <div class="col-lg-6">
                <div class="d-flex justify-content-center flex-column h-100">
                    <div class="section_title">
                        <h6><span>TESTIMONIALS</span></h6>
                        <div class="pb-md-4 py-2">
                            <h1>What Our Client Says </h1>
                        </div>
                    </div>
                    <div class="testimonial_block ">

                        <div class="testimonial_item">

                            <div class="testimonial_text">
                                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nostrum consequuntur
                                    laudantium
                                    atque cumque harum animi id soluta, nesciunt aliquid nam, vitae alias quasi magnam
                                    sequi
                                    eius hic ullam cupiditate obcaecati!</p>
                                <div class="py-4 ">
                                    <h3>Sachin Kumar jha</h3>
                                    <span>Hattiban, Lalitpur</span>
                                </div>

                            </div>
                        </div>
                        <div class="testimonial_item">
                        <div class="d-flex justify-content-center flex-column h-100">
                            <div class="testimonial_text">
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui eaque laudantium fuga id
                                    dolores eligendi quasi, debitis sit aperiam minima iste optio, numquam corporis
                                    fugit
                                    ducimus saepe inventore doloribus expedita.</p>
                                <div class="py-4 ">
                                    <h3>Buddhi Dangol</h3>
                                    <span>Lalitpur</span>
                                </div>

                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH D:\khojsansar\resources\views/frontend/testimonial.blade.php ENDPATH**/ ?>