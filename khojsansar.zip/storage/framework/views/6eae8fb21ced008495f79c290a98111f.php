<?php if(Session::has('success')): ?>
    <div class="padding p-b-0">
        <div class="row">
            <div class="col-lg-12">
                <div class="alert alert-success m-b-0">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <?php echo e(Session::get('success')); ?>

                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if(Session::has('fail')): ?>
    <div class="padding p-b-0">
        <div class="row">
            <div class="col-lg-12">
                <div class="alert alert-danger m-b-0 mt-2">
               
                    <?php echo e(Session::get('fail')); ?>

                </div>
            </div>
        </div>
    </div>
<?php endif; ?><?php /**PATH D:\khojsansar\resources\views/admin/error.blade.php ENDPATH**/ ?>