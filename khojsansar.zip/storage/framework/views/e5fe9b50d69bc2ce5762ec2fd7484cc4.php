
<?php $__env->startSection('page_title','Edit District'); ?>
<?php $__env->startPush("after-styles"); ?>
<link href="<?php echo e(asset('admin/libs/node-waves/waves.min.css')); ?>" rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(asset('admin/libs/simplebar/simplebar.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/libs/flatpickr/flatpickr.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/libs/%40simonwep/pickr/themes/nano.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/libs/%40tarekraafat/autocomplete.js/css/autoComplete.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/libs/choices.js/public/assets/styles/choices.min.css')); ?>">


<?php $__env->stopPush(); ?>
<?php $__env->startSection('container'); ?>





<div class="page">

    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main-content app-content">
        <div class="container-fluid">

            <!-- Page Header -->
            <div class="my-4 page-header-breadcrumb d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div>
                    <h1 class="page-title fw-medium fs-18 mb-2"><?php echo $__env->yieldContent('page_title'); ?></h1>
                    <div class="">
                        <nav>
                            <ol class="breadcrumb mb-0">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo e(url('admin/district')); ?>">Districts</a></li>
                                <li class="breadcrumb-item active" aria-current="page"><?php echo $__env->yieldContent('page_title'); ?></li>
                            </ol>
                        </nav>
                    </div>
                </div>

            </div>
            <!-- Page Header Close -->

            <!-- Start::row-1 -->
            <div class="row">
                <div class="col-xl-12">
                    <div class="card custom-card">
                        <div class="card-header bg-yellow-themed text-fixed-white">
                            <div class="card-title">
                                <?php echo $__env->yieldContent('page_title'); ?>
                            </div>
                        </div>
                        <form action="<?php echo e(route('updatedistrict', $district->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="card-body">
                                <div class="row gy-3">
                                    <div class="col-xl-4">
                                        <label for="input-label" class="form-label">District Name <span
                                                class="text-danger">*</span> :</label>
                                        <input type="text" name="district_name" value="<?php echo e($district->district_name); ?>"
                                            class="form-control select-data" id="input-label"
                                            placeholder="Enter District Name">
                                    </div>
                                    <div class="col-xl-4">
                                        <label for="input-label" class="form-label">Select Province <span
                                                class="text-danger">*</span> :</label>

                                        <select name="province_id" class="form-control select-data">
                                            <option value="<?php echo e($district->province->province_name); ?>">
                                                <?php echo e($district->province->province_name); ?></option>
                                            <option value="" class="bg-yellow-themed text-fixed-white">Select Province *
                                            </option>
                                            <?php $__currentLoopData = $data['provinces']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($province->id); ?>"><?php echo e($province->province_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <?php echo $__env->make('admin.auth.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="card-footer">
                                <button class="btn btn-primary-light btn-wave ms-auto float-end">Edit
                                    District</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <footer class="footer mt-auto py-3 bg-white text-center">
        <div class="container">
            <span class="text-muted"> Copyright © <span id="year"></span> <a href="javascript:void(0);"
                    class="text-dark fw-medium">KhojSansar</a>.
                Designed with <span class="bi bi-heart-fill text-danger"></span> by <a href="javascript:void(0);"
                    target="_blank">
                    <span class="fw-medium text-primary">Digisoft Developers</span>
                </a> All
                rights
                reserved
            </span>
        </div>
    </footer>


</div>

<div class="scrollToTop">
    <span class="arrow lh-1"><i class="ti ti-caret-up fs-20"></i></span>
</div>
<div id="responsive-overlay"></div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startPush("after-scripts"); ?>
<script src="<?php echo e(asset('admin/libs/choices.js/public/assets/scripts/choices.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('admin/libs/%40popperjs/core/umd/popper.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/libs/node-waves/waves.min.js')); ?>"></script>

<!-- SIMPLEBAR JS -->
<script src="<?php echo e(asset('admin/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/simplebar.js')); ?>"></script>

<!-- PICKER JS -->
<script src="<?php echo e(asset('admin/libs/flatpickr/flatpickr.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/libs/%40simonwep/pickr/pickr.es5.min.js')); ?>"></script>

<!-- AUTO COMPLETE JS -->
<script src="<?php echo e(asset('admin/libs/%40tarekraafat/autocomplete.js/autoComplete.min.js')); ?>"></script>

<!-- Apex Charts JS -->
<script src="<?php echo e(asset('admin/libs/apexcharts/apexcharts.min.js')); ?>"></script>

<!-- Sales Dashboard -->
<script src="<?php echo e(asset('admin/js/sales-dashboard.js')); ?>"></script>


<!-- STICKY JS -->
<script src="<?php echo e(asset('admin/js/sticky.js')); ?>"></script>

<!-- DEFAULTMENU JS -->
<script src="<?php echo e(asset('admin/js/defaultmenu.js')); ?>"></script>

<!-- CUSTOM JS -->
<script src="<?php echo e(asset('admin/js/custom.js')); ?>"></script>

<!-- CUSTOM-SWITCHER JS -->
<script src="<?php echo e(asset('admin/js/custom-switcher.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\khojsansar\resources\views/admin/district/district-edit.blade.php ENDPATH**/ ?>