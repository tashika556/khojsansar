<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('page-title'); ?></title>
    <link type="text/css" rel="stylesheet" href="<?php echo e(URL::asset('customer/css/bootstrap.min.css')); ?>">
    <link rel="icon" href="<?php echo e(URL::asset('frontend/img/favicon.ico')); ?>" type="image/x-icon">
    <link type="text/css" rel="stylesheet" href="<?php echo e(URL::asset('customer/css/style.css')); ?>">
</head>

<body>
    <section class="top_header bg-red-themed p-xl-0 p-3 w-100 position-relative">
        <div class="container p-0">
            <div class="row">
                <div class="col-lg-2 col-2">
                    <div class="logo"><a href="index.php"><img
                                src="<?php echo e(URL::asset('admin/images/brand-logos/digi-logo.png')); ?>" alt="logo1"
                                class="img-fluid"></a>
                    </div>
                </div>
                <div class="col-lg-1"></div>
                <div class="col-xl-2 col-2 d-xl-block d-none ">
                    <div class="mt-3">
                        <p class="text-white"><i class="fa fa-phone" aria-hidden="true"></i> 01-5553000</p>
                    </div>
                </div>
                <div class="col-xl-3 col-4 d-xl-block d-none ">
                    <div class="mt-3 d-flex">
                        <p class="text-white"><i class="fa fa-map-marker" aria-hidden="true"></i> Kumaripati - 5
                            Lalitpur Metropolitan</p>

                    </div>
                </div>
                <div class="col-lg-2 col-2 d-xl-block d-none ">
                    <div class="mt-3 d-flex justify-content-evenly">
                        <p class="text-white"><i class="fa fa-facebook" aria-hidden="true"></i></p>
                        <p class="text-white"><i class="fa fa-twitter" aria-hidden="true"></i></p>
                        <p class="text-white"><i class="fa fa-instagram" aria-hidden="true"></i></p>
                        <p class="text-white"><i class="fa fa-youtube" aria-hidden="true"></i></p>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="hamburger-init">
                        <span class="bar top-bar"></span>
                        <span class="bar middle-bar"></span>
                        <span class="bar bottom-bar"></span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="menu-wrapper">
        <ul class="menu">
            <li><a href="about.php">About</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="contact.php">Logout</a></li>
        </ul>
    </div>
    <?php $__env->startSection('container'); ?>
    <?php echo $__env->yieldSection(); ?>
    <?php echo $__env->yieldPushContent('before-scripts'); ?>
    <script src="<?php echo e(asset('customer/js/font-awesom.js')); ?> "></script>
    <script src="<?php echo e(asset('customer/js/jquery-3.6.4.min.js')); ?> "></script>
    <script src="<?php echo e(asset('customer/js/main.js')); ?> "></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    $('#province').on('change', function() {
        var idpradesh = this.value;
        $("#district").html('');
        $.ajax({
            url: "<?php echo e(url('/getDistrict')); ?>",
            type: "POST",
            data: {
                province_id: idpradesh,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            dataType: 'json',
            success: function(res) {
                $('#district').html(' <option value="">Select District-</option>>');
                $.each(res.districts, function(key, value) {
                    $("#district").append('<option value="' + value
                        .id + '">' + value.district_name + '</option>');
                });


            }
        });
    });
    $('#district').on('change', function() {
        var idDistrict = this.value;
        $("#municipality").html('');
        $.ajax({
            url: "<?php echo e(url('/getMunicipality')); ?>",
            type: "POST",
            data: {
                district_id: idDistrict,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            dataType: 'json',
            success: function(result) {
                $('#municipality').html(
                    '<option value="">Select Palika:-</option>');
                $.each(result.municipalities, function(key, value) {
                    $("#municipality").append('<option value="' + value
                        .id + '">' + value.municipality_name + '</option>');
                });
            }
        });
    });
    $('#provinces').on('change', function() {
        var idpradesh = this.value;
        $("#districts").html('');
        $.ajax({
            url: "<?php echo e(url('/getDistrict')); ?>",
            type: "POST",
            data: {
                province_id: idpradesh,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            dataType: 'json',
            success: function(res) {
                $('#districts').html(' <option value="">Select District-</option>>');
                $.each(res.districts, function(key, value) {
                    $("#districts").append('<option value="' + value
                        .id + '">' + value.district_name + '</option>');
                });


            }
        });
    });
    $('#districts').on('change', function() {
        var idDistrict = this.value;
        $("#municipalitys").html('');
        $.ajax({
            url: "<?php echo e(url('/getMunicipality')); ?>",
            type: "POST",
            data: {
                district_id: idDistrict,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            dataType: 'json',
            success: function(result) {
                $('#municipalitys').html(
                    '<option value="">Select Palika:-</option>');
                $.each(result.municipalities, function(key, value) {
                    $("#municipalitys").append('<option value="' + value
                        .id + '">' + value.municipality_name + '</option>');
                });
            }
        });
    });
});
</script>
    <?php echo $__env->yieldPushContent('after-scripts'); ?>
</body>

</html><?php /**PATH D:\khojsansar\resources\views/customer/layout.blade.php ENDPATH**/ ?>