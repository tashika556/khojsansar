<!DOCTYPE html>
<html lang="en" dir="ltr" data-nav-layout="vertical" data-vertical-style="overlay" data-theme-mode="light"
    data-header-styles="light" data-menu-styles="light" data-toggled="close">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>

    <meta charset="UTF-8">
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="Description" content="Mamix - PHP Bootstrap 5 Premium Admin & Dashboard Template">
    <meta name="Author" content="Spruko Technologies Private Limited">
    <meta name="keywords"
        content="phpadmin, php template, admin panel, admin, admin dashboard, php admin panel, admin dashboard ui, php admin, dashboard, php framework, admin dashboard template, bootstrap dashboard, admin theme, admin panel template, php developer">


    <title><?php echo $__env->yieldContent('page-title'); ?> </title>
    <?php echo $__env->yieldPushContent('before-styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/icon-fonts/icons.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/styles.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/libs/bootstrap/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('frontend/css/bootstrap.minn.css')); ?>" />
    <link rel="icon" href="<?php echo e(URL::asset('frontend/img/favicon.ico')); ?>" type="image/x-icon">
    <?php echo $__env->yieldPushContent('after-styles'); ?>
</head>

<body class="bg-white">



<?php /**PATH D:\khojsansar\resources\views/admin/header.blade.php ENDPATH**/ ?>