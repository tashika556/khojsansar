
<?php $__env->startSection('page_title','Personal Information'); ?>
<?php $__env->startSection('container'); ?>
<section class="form-sections padding-section position-relative">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="form-boxes">
                    <div class="row">
                        <div class="col-xl-2 col-md-4 col-12">
                            <div class="info-box active mb-4">
                                <div class="mx-auto text-center mb-4">
                                    <p>Personal</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-2 col-md-4 col-12">
                            <div class="info-box mx-auto text-center mb-4">
                                <p>Business</p>
                            </div>
                        </div>
                        <div class="col-xl-1 col-md-4 col-12">
                            <div class="info-box mx-auto text-center mb-4">
                                <p>Services</p>
                            </div>
                        </div>
                        <div class="col-xl-1 col-md-4 col-12">
                            <div class="info-box mx-auto text-center mb-4">
                                <p>Facility</p>
                            </div>
                        </div>
                        <div class="col-xl-1 col-md-4 col-12">
                            <div class="info-box mx-auto text-center mb-4">
                                <p>Menu</p>
                            </div>
                        </div>
                        <div class="col-xl-2 col-md-4 col-12">
                            <div class="info-box mx-auto text-center mb-4">
                                <p>Special</p>
                            </div>
                        </div>
                        <div class="col-xl-2 col-md-4 col-12">
                            <div class="info-box mx-auto text-center mb-4">
                                <p>Photos & Videos</p>
                            </div>
                        </div>
                        <div class="col-xl-1 col-md-4 col-12">
                            <div class="info-box mx-auto text-center mb-4">
                                <p>Payment</p>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-customer-box">
                                <form>
                                    <div class="row">
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group mb-4">
                                                <label for="exampleFormControlInput1">Authorize</label>
                                                <select name="authorize" class="form-control login-signup" id="">
                                                    <option value="<?php echo e($customer->authorize); ?>">
                                                        <?php echo e($customer->authorizeshow->authorize_name); ?></option>
                                                    <option value="">Select Authorize</option>
                                                    <?php $__currentLoopData = $authorizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->authorize_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleFormControlSelect1">Business / Organization
                                                    Name:</label>
                                                <input type="text" class="form-control" name="business"
                                                    id="exampleFormControlInput1" value="<?php echo e($customer->business); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleFormControlSelect2">Category</label>
                                                <select name="category" class="form-control login-signup" id="">
                                                    <option value="<?php echo e($customer->category); ?>">
                                                        <?php echo e($customer->categoryshow->category_name); ?></option>
                                                    <option value="">Select Catgeory</option>
                                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->category_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleFormControlSelect2">First Name</label>
                                                <input type="text" class="form-control" name="first_name"
                                                    id="exampleFormControlInput1" value="<?php echo e($customer->first_name); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleFormControlSelect2">Middle Name</label>
                                                <input type="text" class="form-control" name="middle_name"
                                                    id="exampleFormControlInput1" value="<?php echo e($customer->first_name); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group mb-4">
                                                <label for="exampleFormControlSelect2">Last Name</label>
                                                <input type="text" class="form-control" name="last_name"
                                                    id="exampleFormControlInput1" value="<?php echo e($customer->first_name); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleFormControlSelect2">Email</label>
                                                <input type="text" class="form-control" name="email"
                                                    id="exampleFormControlInput1" value="<?php echo e($customer->email); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleFormControlSelect2">Phone</label>
                                                <input type="text" class="form-control" name="phone"
                                                    id="exampleFormControlInput1" value="<?php echo e($customer->phone); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group mb-4">
                                                <label for="exampleFormControlSelect2">Cell</label>
                                                <input type="text" class="form-control" name="cell"
                                                    id="exampleFormControlInput1" value="<?php echo e($customer->cell); ?>">
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="mx-auto text-center">
                                                <h5><strong>Permanent Address</strong></h5>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group mb-4">
                                                <label for="exampleFormControlSelect2">Province</label>
                                                <input type="text" class="form-control" name="last_name"
                                                    id="exampleFormControlInput1"
                                                    value="<?php echo e($customer->permanentState->province_name); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleFormControlSelect2">District</label>
                                                <input type="text" class="form-control" name="email"
                                                    id="exampleFormControlInput1"
                                                    value="<?php echo e($customer->permanentDistrict->district_name); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleFormControlSelect2">Municipality / Palika</label>
                                                <input type="text" class="form-control" name="phone"
                                                    id="exampleFormControlInput1"
                                                    value="<?php echo e($customer->permanentMunicipality->municipality_name); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group mb-4">
                                                <label for="exampleFormControlSelect2">Ward</label>
                                                <input type="text" class="form-control" name="cell"
                                                    id="exampleFormControlInput1"
                                                    value="<?php echo e($customer->permanent_ward); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group mb-4">
                                                <label for="exampleFormControlSelect2">Tole</label>
                                                <input type="text" class="form-control" name="cell"
                                                    id="exampleFormControlInput1"
                                                    value="<?php echo e($customer->permanent_tole); ?>">
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="mx-auto text-center">
                                                <h5><strong>Temporary Address</strong></h5>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group mb-4">
                                                <label for="exampleFormControlSelect2">Province</label>
                                                <select name="temporary_state" id="province"
                                                    class="form-control login-signup">
                                                    <option value="">- - Province - - *</option>
                                                    <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->province_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleFormControlSelect2">District</label>
                                                <select id="district" name="temporary_district"
                                                    class="form-control login-signup">

                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleFormControlSelect2">Municipality / Palika</label>
                                                <select id="municipality" name="temporary_municipality"
                                                    class="form-control login-signup">

                                                </select>

                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group mb-4">
                                                <label for="exampleFormControlSelect2">Ward</label>
                                                <input type="text" class="form-control" name="temporary_ward"
                                                    id="exampleFormControlInput1" value="">
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-md-6 col-12">
                                            <div class="form-group mb-4">
                                                <label for="exampleFormControlSelect2">Tole</label>
                                                <input type="text" class="form-control" name="temporary_tole"
                                                    id="exampleFormControlInput1" value="">
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
                                                                                                                                                                                                                                                 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\khojsansar\resources\views/customer/home.blade.php ENDPATH**/ ?>