
<?php $__env->startSection('page_title','View Pending Customers'); ?>
<?php $__env->startPush("after-styles"); ?>
<link href="<?php echo e(asset('admin/libs/node-waves/waves.min.css')); ?>" rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(asset('admin/libs/simplebar/simplebar.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/libs/flatpickr/flatpickr.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/libs/%40simonwep/pickr/themes/nano.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/libs/%40tarekraafat/autocomplete.js/css/autoComplete.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/libs/choices.js/public/assets/styles/choices.min.css')); ?>">


<?php $__env->stopPush(); ?>
<?php $__env->startSection('container'); ?>





<div class="page">

    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main-content app-content">
        <div class="container-fluid">

            <!-- Start::page-header -->
            <div class="my-4 page-header-breadcrumb d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div>
                    <h1 class="page-title fw-medium fs-18 mb-2"><?php echo $__env->yieldContent('page_title'); ?></h1>
                    <ol class="breadcrumb mb-0">

                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/pendingcustomer')); ?>">Pending Customers</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo $__env->yieldContent('page_title'); ?></li>
                    </ol>
                </div>
                <div>


                </div>
            </div>

            <div class="row">

                <div class="col-xl-12">
                    <div class="card custom-card">
                        <div class="card-header justify-content-between">
                            <div class="card-title">
                                Manage Pending Customers
                            </div>


                            <?php echo $__env->make('admin.auth.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="d-flex">
                                <div class="header-element header-search d-md-block d-none my-auto">
                                    <input type="text" class="header-search-bar form-control" id="header-search"
                                        placeholder="Search for Results..." spellcheck=false autocomplete="off"
                                        autocapitalize="off">
                                    <a href="javascript:void(0);" class="header-search-icon border-0">
                                        <i class="bi bi-search"></i>
                                    </a>
                                </div>


                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table text-nowrap">
                                    <thead>
                                        <tr class="Customers-list">
                                            <th class="bg-yellow-themed text-fixed-white " scope="col">S.No.</th>
                                            <th class="bg-yellow-themed text-fixed-white " scope="col">Customers Name
                                            </th>
                                            <th class="bg-yellow-themed text-fixed-white " scope="col">Category
                                            </th>
                                            <th class="bg-yellow-themed text-fixed-white " scope="col">Business Name
                                            </th>
                                            <th class="bg-yellow-themed text-fixed-white " scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="dataTable">
                                        <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="Customers-list">
                                            <td><?php echo e($index + 1); ?></td>
                                            <td class="data-name"><?php echo e($cus->first_name); ?></td>
                                            <td class="province-name"><?php echo e($cus->authorizeshow->authorize_name); ?></td>
                                            <td class="muni-name"><?php echo e($cus->categoryshow->category_name); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('viewpendingcustomers', $cus->id)); ?>"
                                                    class="btn btn-info btn-icon btn-sm">
                                                    <i class="ri-eye-line"></i>
                                                </a>

                                                <form action="<?php echo e(route('customer.destroy', $cus->id)); ?>" method="POST"
                                                    onsubmit="return confirmDelete()" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit"
                                                        class="btn btn-danger-light btn-icon ms-1 btn-sm invoice-btn">
                                                        <i class="ri-delete-bin-5-line"></i>
                                                    </button>
                                                </form>
                                                <div class="dropdown d-inline">
                                                    <button
                                                        class="btn btn-primary-light btn-icon btn-sm dropdown-toggle"
                                                        type="button" id="dropdownMenuButton<?php echo e($cus->id); ?>"
                                                        data-bs-toggle="dropdown" aria-expanded="false">
                                                        <i class="ri-more-2-line"></i>
                                                    </button>
                                                    <ul class="dropdown-menu dropdown-status"
                                                        aria-labelledby="dropdownMenuButton<?php echo e($cus->id); ?>">
                                                        <li>
                                                            <form
                                                                action="<?php echo e(route('pendingcustomer.verify', $cus->id)); ?>"
                                                                method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <button type="submit"
                                                                    class="dropdown-item">Verify</button>
                                                            </form>
                                                        </li>
                                                        <li>
                                                            <button class="dropdown-item" data-bs-toggle="modal"
                                                                data-bs-target="#rejectModal<?php echo e($cus->id); ?>">
                                                                Reject
                                                            </button>
                                                        </li>
                                                    </ul>
                                                </div>

                                                <div class="modal fade" id="rejectModal<?php echo e($cus->id); ?>" tabindex="-1"
                                                    aria-labelledby="rejectModalLabel<?php echo e($cus->id); ?>" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title"
                                                                    id="rejectModalLabel<?php echo e($cus->id); ?>">Reject Reason
                                                                </h5>
                                                                <button type="button" class="btn-close"
                                                                    data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <form
                                                                action="<?php echo e(route('pendingcustomer.reject', $cus->id)); ?>"
                                                                method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="modal-body">
                                                                    <div class="mb-3">
                                                                        <label for="rejectionReason<?php echo e($cus->id); ?>"
                                                                            class="form-label">Reason for
                                                                            Rejection</label>
                                                                        <textarea class="form-control"
                                                                            id="rejectionReason<?php echo e($cus->id); ?>"
                                                                            name="rejection_reason" rows="3"
                                                                            required></textarea>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-bs-dismiss="modal">Close</button>
                                                                    <button type="submit"
                                                                        class="btn btn-primary">Submit</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div id="pagination-controls" class="d-flex justify-content-center mt-3">
                        </div>
                    </div>
                </div>


            </div>
        </div>


        <footer class="footer mt-auto py-3 bg-white text-center">
            <div class="container">
                <span class="text-muted"> Copyright © <span id="year"></span> <a href="javascript:void(0);"
                        class="text-dark fw-medium">KhojSansar</a>.
                    Designed with <span class="bi bi-heart-fill text-danger"></span> by <a href="javascript:void(0);"
                        target="_blank">
                        <span class="fw-medium text-primary">Digisoft Developers</span>
                    </a> All
                    rights
                    reserved
                </span>
            </div>
        </footer>


    </div>

    <div class="scrollToTop">
        <span class="arrow lh-1"><i class="ti ti-caret-up fs-20"></i></span>
    </div>
    <div id="responsive-overlay"></div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startPush("after-scripts"); ?>

<script src="<?php echo e(asset('admin/libs/choices.js/public/assets/scripts/choices.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('admin/libs/%40popperjs/core/umd/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/libs/node-waves/waves.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/simplebar.js')); ?>"></script>
<script src="<?php echo e(asset('admin/libs/flatpickr/flatpickr.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/libs/%40simonwep/pickr/pickr.es5.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/libs/%40tarekraafat/autocomplete.js/autoComplete.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/libs/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/sales-dashboard.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/sticky.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/defaultmenu.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/custom-switcher.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\khojsansar\resources\views/admin/customers/pending/pending.blade.php ENDPATH**/ ?>