
                <div class="side_block">
                    <div class="ul_wrapp bg_gray p-4 ">
                        <div class="ul_list ">
                            <div class="sidebar_title mb-4">
                                <h3><span>Kathmandu</span></h3>
                            </div>
                            <ul>
                                <a href="news_detail.php">
                                    <h4>The Chimney Restaurant</h4>
                                    <div class="py-2">
                                        <span> kumaripati Lalitpur, Nepal</span>
                                        <span>01-5553000</span>
                                    </div>

                                </a>
                                <a href="news_detail.php">
                                    <h4>Thamel House Restaurant</h4>
                                    <div class="py-2">
                                        <span> kumaripati Lalitpur, Nepal</span>
                                        <span>01-5553000</span>
                                    </div>

                                </a>
                                <a href="news_detail.php">
                                    <h4>The Chimney Restaurant</h4>
                                    <div class="py-2">
                                        <span> kumaripati Lalitpur, Nepal</span>
                                        <span>01-5553000</span>
                                    </div>

                                </a>
                            </ul>
                        </div>
                    </div>
                    <div class="ul_wrapp bg_gray p-4 mt-4">
                        <div class="ul_list ">

                            <div class="sidebar_title mb-4">
                                <h3><span>Favourite Location</span></h3>
                            </div>
                            <ul>
                                <a href="news_detail.php">
                                    <h4>Thamel House Restaurant</h4>
                                    <div class="py-2">
                                        <span> kumaripati Lalitpur, Nepal</span>
                                        <span>01-5553000</span>
                                    </div>

                                </a>
                                <a href="news_detail.php">
                                    <h4>Thamel House Restaurant</h4>
                                    <div class="py-2">
                                        <span> kumaripati Lalitpur, Nepal</span>
                                        <span>01-5553000</span>
                                    </div>

                                </a>
                                <a href="news_detail.php">
                                    <h4>Thamel House Restaurant</h4>
                                    <div class="py-2">
                                        <span> kumaripati Lalitpur, Nepal</span>
                                        <span>01-5553000</span>
                                    </div>

                                </a>

                            </ul>
                        </div>
                    </div>
                </div>
  