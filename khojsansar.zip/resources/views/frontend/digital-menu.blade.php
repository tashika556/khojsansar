<?php include 'header.php'; ?>
<section class="bg_img banner d-flex justify-content-center align-items-center dark_bg"
    style="background-image: url(img/slider/slider02.jpg);">
    <div class="banner_content text-white">

    </div>
</section>


<?php include "footer.php"; ?>